---
title: "Distributed Algorithms for High-Dimensional Statistical Inference and Structure Learning with Heterogeneous Data"
collection: publications
permalink: /publication/2024-04-11-paper
date: 2025-03-13
paperurl: 'https://www3.stat.sinica.edu.tw/ss_newpaper/SS-2025-0087_na.pdf'
citation: 'Hongru Zhao, and Xiaotong Shen. Statistica Sinica (2025).'
topics:
  - high-dimensional-statistics
---
