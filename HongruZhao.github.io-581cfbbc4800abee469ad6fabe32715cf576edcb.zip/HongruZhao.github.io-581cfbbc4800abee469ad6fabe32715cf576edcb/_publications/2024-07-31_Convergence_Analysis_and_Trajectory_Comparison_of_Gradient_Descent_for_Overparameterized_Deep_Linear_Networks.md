---
title: "Convergence Analysis and Trajectory Comparison of Gradient Descent for Overparameterized Deep Linear Networks"
collection: publications
permalink: /publication/2024-07-31-paper
date: 2024-04-02
paperurl: 'https://openreview.net/forum?id=jG7ndW7UHp'
citation: 'Hongru Zhao, Jinchao Xu. Transactions on Machine Learning Research (2024)'
topics:
  - generative-ai-and-reiforcement-learning
---
