---
title: "Limiting empirical spectral distribution for products of rectangular matrices"
collection: publications
date: 2021-10-15
paperurl: 'https://hongruzhao.github.io/files/Limiting_Empirical_Spectral_Distribution_for_Products_of_Rectangular_Matrices.pdf'
citation: 'Yongcheng Qi, and Hongru Zhao. Journal of Mathematical Analysis and Applications 502, no. 2 (2021): 125237.'
topics:
  - high-dimensional-statistics
---

