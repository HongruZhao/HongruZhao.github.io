---
title: "Subspace Decompositions for Association Structure Learning in Multivariate Categorical Response Regression"
collection: publications
date: 2025-03-14
citation: 'Hongru Zhao, Aaron J. Molstad, and Adam J. Rothman. Preprint (2025)'
topics:
  - high-dimensional-statistics
---
