---
title: "Globally-Optimal Greedy Active Sequential Estimation"
collection: publications
date: 2025-03-15
paperurl: 'https://ieeexplore.ieee.org/document/10926541'
citation: 'Xiaoou Li, and Hongru Zhao. IEEE Transactions on Information Theory 71, no. 5 (2025): 3871–3924.'
topics:
  - adaptive-design-and-sequential-estimation
---
