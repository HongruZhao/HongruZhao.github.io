---
title: "STAT 3011 - Intro Statistical Analysis"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2023-fall-teaching
venue: "UMN, School of Statistics"
date: 2023-09-01
location: "Twin Cities, USA"
---
