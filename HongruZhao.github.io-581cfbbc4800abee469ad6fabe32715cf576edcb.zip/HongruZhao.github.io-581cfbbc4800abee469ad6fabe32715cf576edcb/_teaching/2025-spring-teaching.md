---
title: "STAT 3301 - Regression and Statistical Computing"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2025-spring-teaching
venue: "UMN, School of Statistics"
date: 2025-01-21
location: "Twin Cities, USA"
---

