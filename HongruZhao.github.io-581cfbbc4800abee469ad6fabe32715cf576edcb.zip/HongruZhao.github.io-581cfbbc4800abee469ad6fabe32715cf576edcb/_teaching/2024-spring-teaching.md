---
title: "STAT 3301 - Regression and Statistical Computing"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2024-fall-teaching
venue: "UMN, School of Statistics"
date: 2024-01-16
location: "Twin Cities, USA"
---

