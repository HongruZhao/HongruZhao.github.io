---
title: "STAT 4101 - Theory of Statistics I"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/2024-fall-teaching
venue: "UMN, School of Statistics"
date: 2024-09-01
location: "Twin Cities, USA"
---

